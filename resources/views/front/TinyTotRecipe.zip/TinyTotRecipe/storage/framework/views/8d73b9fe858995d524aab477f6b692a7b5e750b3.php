
<?php $__env->startSection('body'); ?>

<div class="card-body">
    <div class="col-lg-12 log-md-12 col-xs-12 bodyHeader">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 search">
                <h4 class="addRe">Your Recipe List</h4>
            </div>
        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 mainBody">
        <br><br>
        <div class="container">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <h5 style="text-align: left"><a href="<?php echo e(route('addRecipe')); ?>" class="btn btn-info">Add Recipe</a></h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Recipe Name</th>
                        <th>User Name</th>
                        <th>Serves</th>
                        <th>Recomended Age</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($r->recipe_name); ?></td>
                            <td><?php echo e($r->user->name); ?></td>
                            <td><?php echo e($r->serves); ?></td>
                            <td><?php echo e($r->recomended_age); ?></td>
                            <td>
                                <img src="<?php echo e(url("recipeImage/$r->image")); ?>" alt="" width="150px"  class="image-responsive">
                                
                            </td>
                            <td>
                                <a href="<?php echo e(route('viewRecipe',$r->id)); ?>" class="btn btn-info"><i class="fa-solid fa-eye"></i></a>
                                <a href="<?php echo e(route('editRecipe',$r->id)); ?>" class="btn btn-info"><i class="fa-solid fa-pen-to-square"></i></a>
                                <a href="<?php echo e(route('deleteRecipe',$r->id)); ?>" class="btn btn-danger" onclick="return confirm('Are You Sure!!')"><i class="fa-solid fa-trash"></i></a>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">No recipe added yet</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($recipe->links('pagination::bootstrap-4')); ?>

        </div>

        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/recipeList.blade.php ENDPATH**/ ?>