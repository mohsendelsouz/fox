<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="fa-solid fa-utensils"></i></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('index')); ?>">Home</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('forum')); ?>">Forums</a>
                </li>
                
                <?php if(Auth::user()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('recipes')); ?>">Recipes</a>
                </li>
                <?php endif; ?>

            </ul>
            
            <?php if(Auth::user()!=''): ?>



            <?php if(Auth::user()->role=='admin'): ?>
            <ul class="navbar-nav">
                <li class="nav-item ">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-user"></i>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('report')); ?>">Report</a>
                </li>

                

                </li>
            </ul>
            <?php elseif(Auth::user()->role=='user'): ?>
            <ul class="navbar-nav">
                <li class="nav-item ">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-user"></i>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('recipeList')); ?>">Your Recipes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('favoriteList')); ?>">Favorites</a>
                </li>
                

                

                </li>
            </ul>
            <?php endif; ?>

            <?php endif; ?>

        </div>
    </div>
</nav><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/header/header.blade.php ENDPATH**/ ?>