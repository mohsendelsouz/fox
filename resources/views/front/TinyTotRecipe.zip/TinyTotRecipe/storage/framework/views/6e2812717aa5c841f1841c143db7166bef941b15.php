
<?php $__env->startSection('body'); ?>
<div class="card-body">
    <div class="col-lg-12 log-md-12 col-xs-12 bodyHeader">
        <div class="row">
            <div class="col-md-4 col-lg-4 col-xs-12 bodyHeaderText">
                <h4 class="babyFoodiesText">Baby Foodies</h4>
                <h5 class="babyFoodiesTextShort">Baby-led Weaning <span class="app">APP</span>roved </h5>
            </div>
            <div class="col-md-4 col-lg-4 col-xs-12 search">
                
                    <h4 class="ss"><input type="text" placeholder="Search for Recipes" class="in searchName"
                            id="name"><button class="btn btn-defaul se" id="search">Search</button></h4>
                
            </div>
            <div class="col-md-4 col-lg-4 col-xs-12">
                <img src="<?php echo e(url('assets/image/baby-2423896_960_720.jpg')); ?>" alt=""
                    class="bodyHeaderImage image-responsive">
            </div>
            
        </div>
       
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 mainBody">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12">
                <h4 class="community">JOIN OUR COMMUNITY</h4>
            </div>

        </div>
        <div class="container">
            
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12">
                    <div class="row" id="result">

                    </div>

                </div>
                <?php $__empty_1 = true; $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($key<4): ?> <div class="col-md-3 col-lg-3 col-xs-6 bodyImage">
                    <img src="<?php echo e(url("recipeImage/$r->image")); ?>" alt=""
                    class="bodyHeaderImage image-responsive">
                    <?php if(Auth::user()!=''): ?>
                    <h4><a href="<?php echo e(route('viewRecipe',$r->id)); ?>" class="addRecipeTag"
                        style="color: black"><?php echo e($r->recipe_name); ?></a></h4>
                        <?php else: ?>
                        <h4><a href="#" class="addRecipeTag"
                            style="color: black" onclick="return confirm('You Have to Login first to see the Details')"><?php echo e($r->recipe_name); ?></a></h4>
                    <?php endif; ?>
                    
            </div>
            <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                <?php endif; ?>
                
                
                <?php if(Auth::user()==''): ?>
                <div class="col-md-12 col-lg-12 col-xs-12">
                    
                    <a href="<?php echo e(route('login')); ?>">
                        <button class="btn  reg" data-bs-toggle="modal"><i
                            class="fa-solid fa-user"></i> Registration / Login</button>
                    </a>
                </div>
                <?php endif; ?>
            </div><br><br><br>

        </div>
    </div>
</div>


<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel">Registration</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <tr>
                            <td>Your Name</td>
                            <td>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Your Email</td>
                            <td>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Confirm Password</td>
                            <td>
                                <input id="password-confirm" type="password" class="form-control"
                                    name="password_confirmation" required autocomplete="new-password">
                            </td>
                        </tr>

                    </table>
            </div>
            <div class="modal-footer">

                <button type="submit" class="btn btn-primary">Register</button>
                <button class="btn btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal"
                    data-bs-dismiss="modal">Login</button>
            </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel2">Login</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <tr>
                            <td>Your Email</td>
                            <td>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Your Password</td>
                            <td>
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                    </table>

            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal"
                    data-bs-dismiss="modal">Back to Registration</button>
                    <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                <button class="btn btn-primary" type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
//  
$('#search').on('click',function(){
    let data = $('.searchName').val()
    if(data!=''){
    $.ajax({
               type:'get',
               url:'/search',
               
               data: {
                     name: data
                     
                  },
               success:function(data) {
                  let dta = data.data
                  
                  if(dta!=''){
                    let tr =''
                    $.each(dta, function(index, value) {
                        // console.log(value.recipe_name);
                        
                            // tr+= '<div class="row" >'
                            tr += '<div class="col-md-3 col-lg-3 col-xs-3 ">'
                            tr+= '<img src="recipeImage/'+value.image+'" alt="" class="bodyHeaderImage image-responsive">'
                            tr+='<h4><a href="<?php echo e(route('viewRecipe',$r->id)); ?>" class="addRecipeTag" style="color: black">'+value.recipe_name+'</a></h4>'
                            tr+='</div>'
                            // tr+='</div>'
                        
                    
                    });
                    
                    $('#result').html(tr)
                    $('.bodyImage').html('')
                  }else{
                    let tr = ''
                    alert('We cann\'t find what you are lookhing for')
                    $('#result').html(tr)
                  }
                  



               }
            });
        }
 })



});
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/index.blade.php ENDPATH**/ ?>