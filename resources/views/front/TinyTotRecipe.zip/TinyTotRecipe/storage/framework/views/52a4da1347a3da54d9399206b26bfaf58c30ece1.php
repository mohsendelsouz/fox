
<?php $__env->startSection('body'); ?>

<div class="card-body">
    <div class="col-lg-12 log-md-12 col-xs-12 bodyHeader">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 search">
                <h4 class="addRe">Add Recipes</h4>
            </div>
        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 mainBody">
        <br><br>
        <div class="container">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('insertRecipe')); ?>" method="POST" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <table class="table table-bordered">
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="image" class="form-control">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td>Video (Optional)</td>
                        <td><input type="text" name="video" class="form-control" placeholder="Video Link" value="<?php echo e(old('video')); ?>"></td>
                    </tr>
                    <tr>
                        <td>Recipe Name</td>
                        <td colspan="3">
                            <input type="text" name="recipe_name" class="form-control" placeholder="Recipe Name" value="<?php echo e(old('recipe_name')); ?>">
                            <?php $__errorArgs = ['recipe_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Prep Time (Minutes)</td>
                        <td>
                            <input type="text" name="prep_time" class="form-control" placeholder="Prepration Time in Minutes. Ex. 10" value="<?php echo e(old('prep_time')); ?>">
                            <?php $__errorArgs = ['prep_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td>Cook Time (Minutes)</td>
                        <td>
                            <input type="text" name="cook_time" class="form-control" placeholder="Cook Time in Minutes. Ex. 15" value="<?php echo e(old('cook_time')); ?>">
                            <?php $__errorArgs = ['cook_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Serves (Person)</td>
                        <td>
                            <input type="text" name="serves" class="form-control" placeholder="How many babies you can serv. Ex. 5" value="<?php echo e(old('serves')); ?>">
                            <?php $__errorArgs = ['serves'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td>Recomended Age</td>
                        <td>
                            <input type="text" name="recomended_age" class="form-control" placeholder="Recomended Age for this Recipe" value="<?php echo e(old('recomended_age')); ?>">
                            <?php $__errorArgs = ['recomended_age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Ingredients</td>
                        <td colspan="3">
                            <textarea name="ingredients" id="" cols="15" rows="5" class="form-control" placeholder="What ingredients we need to prepare this food"><?php echo e(old('ingredients')); ?></textarea>
                            <?php $__errorArgs = ['ingredients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Step To Recreate</td>
                        <td colspan="3" style="text-align: left">
                            <input type="text" name="steps[]" class="form-control" placeholder='Step 1' value="<?php echo e(old('steps[]')); ?>">
                            <?php $__errorArgs = ['steps[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span id="more"></span>
                            <br>
                            <a class="btn btn-info" id="addMoreStep">Add More Step</a>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" class="btn btn-primary" value="Add Recipe"></td>
                        <td colspan="3"></td>
                    </tr>
                </table>
            </form>
        </div>

        
    </div>
</div>
<script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        let c  = 1; 
        $('#addMoreStep').on('click',function(e){
            e.preventDefault();
            c++
            let td = "<div class='new_fild_"+c+"'><hr><input type='text' class='form-control remove_"+c+"' name='steps[]' placeholder='Step "+c+"'><br><a class='btn btn-danger' value='"+c+"' id='removeFild'>Remove</a><hr></div>"
            $('#more').append(td)

            
        })
        $(document).on('click', '#removeFild', function() {
        let test = $(this).attr('value')


        $('.new_fild_' + test).remove()

    });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/addRecipe.blade.php ENDPATH**/ ?>