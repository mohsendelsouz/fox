
<?php $__env->startSection('body'); ?>
<div class="card-body">
    <div class="col-lg-12 log-md-12 col-xs-12 bodyHeader">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 search">
                <h4 class="addRe">FORUMS</h4>
            </div>
        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 mainBody">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12">
                <h4 class="community">Create Forum</h4>
            </div>

        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12">
                    <form action="<?php echo e('saveForum'); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <table class="table table-bordered">
                            <tr>
                                <td>Forum Title</td>
                                <td>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Forum Name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span style="color:red"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td>Discussion Topic</td>
                                <td>
                                    <input type="text" name="discussion_topic" class="form-control" placeholder="Discussion Topic" value="<?php echo e(old('discussion_topic')); ?>">
                                    <?php $__errorArgs = ['discussion_topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span style="color:red"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td><input type="submit" class="btn btn-primary"></td>
                                <td colspan="3"></td>
                            </tr>
                        </table>
                    </form>
                </div>
                
            </div>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/addForum.blade.php ENDPATH**/ ?>