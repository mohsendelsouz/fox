
<?php $__env->startSection('body'); ?>
<div class="card-body">
    <div class="col-lg-12 log-md-12 col-xs-12 bodyHeader">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 search">
                <h4 class="prifile">
                    <i class="fa-solid fa-user" style="font-size: 70px;"></i> <?php echo e($user->name); ?><br>
                    <a href="" style="font-size: 20px;" data-bs-toggle="modal" data-bs-target="#exampleModal">Update
                        Profile</a>
                </h4>

            </div>
        </div>
    </div>
    
    <div class="col-md-12 col-lg-12 col-xs-12 mainBody">
        <?php if(Auth::user()->role=='user'): ?>
        
       
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12">
                    <h4  class="community">Notifications</h4><br>
                    <table class="table table-bordered">
                        <thead >
                            <th>Date</th>
                            <th>Message</th>
                            
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th><?php echo e(date('d-m-Y', strtotime($n->created_at))); ?></th>
                                <th><span style="color: red"><?php echo e($n->message); ?></span></th>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <th >no notification</th>
                                <th><span style="color: red">no notification</span></th>
                                
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        
                    </table>
                    <?php echo e($notification->links('pagination::bootstrap-4')); ?>

    
                </div>
    
    
            </div>
    
        </div>
       
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12">
                <h4 class="community" >Your Approved Recipes</h4>
            </div>

        </div>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
       
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Recipe Name</th>
                                <th>User Name</th>
                                <th>Serves</th>
                                <th>Recomended Age</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($r->recipe_name); ?></td>
                                    <td><?php echo e($r->user->name); ?></td>
                                    <td><?php echo e($r->serves); ?></td>
                                    <td><?php echo e($r->recomended_age); ?></td>
                                    <td>
                                        <img src="<?php echo e(url("recipeImage/$r->image")); ?>" alt="" width="150px"  class="image-responsive">
                                        
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('viewRecipe',$r->id)); ?>" class="btn btn-info"><i class="fa-solid fa-eye"></i></a>
                                        <a href="<?php echo e(route('editRecipe',$r->id)); ?>" class="btn btn-info"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('deleteRecipe',$r->id)); ?>" class="btn btn-danger" onclick="return confirm('Are You Sure!!')"><i class="fa-solid fa-trash"></i></a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7">No recipe added yet</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($recipe->links('pagination::bootstrap-4')); ?>


                </div>


            </div>

        </div>
        <?php endif; ?>
        <?php if(Auth::user()->role=='admin'): ?>
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12">
                <h4 class="community">User List</h4>
            </div>

        </div>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
       
       
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12">
                    <h4 style="text-align: left">Update User Role</h4>
                    <table class="table table-bordered">
                        <thead style="background-color: yellow">
                            <tr>
                                <th>SL</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($r->name); ?></td>
                                    <td><?php echo e($r->email); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('update',$r->id)); ?>" method="post" >
                                            <?php echo csrf_field(); ?>
                                            <select name="role" id="" class="form-control">
                                                <option value="<?php echo e($r->role); ?>"><?php echo e($r->role); ?></option>
                                                <option value="admin">Admin</option>
                                                <option value="user">User</option>
                                            </select>
                                            <input type="submit" class="btn btn-info" value="Update">
                                        </form>
                                       
                                        
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('deleteUser',$r->id)); ?>" class="btn btn-danger" onclick="return confirm('Are You Sure!!')"><i class="fa-solid fa-trash"></i></a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7">No User Added Yeat</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($users->links('pagination::bootstrap-4')); ?>


                </div>


            </div>

        </div>
        
        <?php endif; ?>
        
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('updateProfile')); ?>">
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <table class="table table-bordered">
                        <tr>
                            <td>Your Name</td>
                            <td>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>

                                
                            </td>
                        </tr>
                        <tr>
                            <td>Your Email</td>
                            <td>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e($user->email); ?>" required autocomplete="email">

                                
                            </td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="new-password" value="<?php echo e($user->password); ?>">

                                
                            </td>
                        </tr>
                        

                    </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\UPWorkUmme\TinyTotRecipe\resources\views/front/profile.blade.php ENDPATH**/ ?>